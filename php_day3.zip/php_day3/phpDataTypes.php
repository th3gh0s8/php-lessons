<?php

$stringData = "ABCD";
echo $stringData;

echo "<br>";

$numData = 10;
echo $numData;

echo "<br>";

$flotData = 12343.45;
echo $flotData;

$boolData = true;
echo $boolData;

$nullData = null;
echo $nullData;

//$objData = new php obj;
//echo $nullData;

?>