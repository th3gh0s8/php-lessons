<?php
session_start();



$is_login = "";



if (isset($_SESSION['is_login'])) {
    $is_login = $_SESSION['is_login'];
} else {
    
}


if ($is_login == "") {
    header("Location: login.php?msg=plzz login again !");
    die();
}
?>
<h1>welcome</h1>



<?php


echo "<a href='logout.php'>Logout</a>"
?>
