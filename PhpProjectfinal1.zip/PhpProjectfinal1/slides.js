/*var x=1;

function b(){
    var y=document.getElementById("asus");
    y.className='dvi-1 asus-'+x;
    x++;
    if(x===4){
        x=1;
    }
}
