<!DOCTYPE html>

<html>
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link type="text/css" rel="stylesheet" href="style1.css"/>
    </head>
    <body>
        <div class="header">
  
            <table class="tbl">
            <tr>
                <td><div class="head"><h1>BuyLap.lk</h1></div></td>
                <td><a href="#"><button class="button">Track My Order</button></a></td>
                <td><a href="#"><button class="button">Purchasing</button></a></td>
                <td><a href="#"><button class="button">Login </button></a></td>
                <td><a href="#"><button class="button">Sign Up </button></a></td>
            </tr>
        </table>
  
            <table style="margin-top: -60px;">
            <tr>

                
                
                <td>
                    
                    <form>
                        <div  style="text-align: center;">

                            <input class="search" type="text" name="name" id="name"/>
                            <input class="button1" type="submit" value="search" name="search"/>

                        </div>
                    </form>
                </td>
            </tr>
        </table>
            </div>
        <div class="slide"></div>
        
        <table class="t">
            <tr>
                <td>

                    <div class="div1">
                        <a href="dell.php">
                            <img src="laptop8.jpg" class="im1"/></a>
                        <br>
                        <table style="margin-left: 120px;">
                            <tr>
                                <td class="txt">
                                    Dell Core i5 7th Gen
                                </td>

                            </tr>
                            <tr>
                                <td class="txt">
                                    4GB DDR5
                                </td>
                            </tr>
                            <tr>
                                <td class="txt">
                                    LKR 125,000
                                </td>
                            </tr>

                        </table>

                    </div>


                </td>
                <td>
                    <div class="div2">


                        <a href="#">
                            <img src="laptop9.jpg" class="im1"/></a>
                        <br>
                        <table style="margin-left: 120px;">
                            <tr>
                                <td class="txt">
                                    Acer Core i7 10th Gen
                                </td>

                            </tr>
                            <tr>
                                <td class="txt">
                                    8GB DDR5
                                </td>
                            </tr>
                            <tr>
                                <td class="txt">
                                    LKR 190,000
                                </td>
                            </tr>

                        </table>


                    </div>
                </td>
                <td>
                    <div class="div3">
                        <a href="asus.php">
                            <img src="laptopimg.jpg" class="im1"/></a>
                        <br>
                        <table style="margin-left: 120px;">
                            <tr>
                                <td class="txt">
                                    Asus Core i5 7th Gen
                                </td>

                            </tr>
                            <tr>
                                <td class="txt">
                                    6GB DDR5
                                </td>
                            </tr>
                            <tr>
                                <td class="txt">
                                    LKR 140,000
                                </td>
                            </tr>

                        </table>



                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="div3">
                        <a href="#">
                            <img src="laptops11.jpg" class="im1"/></a>
                        <br>
                        <table style="margin-left: 120px;">
                            <tr>
                                <td class="txt">
                                    Acer Core i7 10th Gen
                                </td>

                            </tr>
                            <tr>
                                <td class="txt">
                                    8GB DDR5
                                </td>
                            </tr>
                            <tr>
                                <td class="txt">
                                    LKR 210,000
                                </td>
                            </tr>

                        </table>
                    </div>
                </td>
                <td>
                    <div class="div1">
                        <a href="#">
                            <img src="laptops12.jpg" class="im1"/></a>
                        <br>
                        <table style="margin-left: 120px;">
                            <tr>
                                <td class="txt">
                                    Lenovo ideapad Core i5 10th Gen
                                </td>

                            </tr>
                            <tr>
                                <td class="txt">
                                    4GB DDR5
                                </td>
                            </tr>
                            <tr>
                                <td class="txt">
                                    LKR 105,000
                                </td>
                            </tr>

                        </table>
                    </div>
                </td>
                <td>
                    <div class="div2"><a href="hp.php">
                            <img src="laptops13.jpg" class="im1"/></a>
                        <br>
                        <table style="margin-left: 120px;">
                            <tr>
                                <td class="txt">
                                    hp Core i5 10th Gen
                                </td>

                            </tr>
                            <tr>
                                <td class="txt">
                                    6GB DDR5
                                </td>
                            </tr>
                            <tr>
                                <td class="txt">
                                    LKR 110,000
                                </td>
                            </tr>

                        </table></div>
                </td>
            </tr>
        </table>
    </body>
</html>
