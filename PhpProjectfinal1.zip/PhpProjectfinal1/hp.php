<!DOCTYPE html>
<html>
    <head>
        <title>s</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="stylesheet" type="text/css" href="style1.css">
    </head>
    <body class="im5" onload="setInterval(c,10000);">
      <a href="index.html">
        <div class='l0g0'></div>
        </a>
        <script type='text/javascript' src='ani.js'> </script>

        <table class="t-respo" class="fo">
            <tr>
                <td class="hedder">       <!-- <div class="header">
  
  <table class="tbl">
  <tr>
      <td><div class="head"><h1>BuyLap.lk</h1></div></td>
      <td><a href="#"><button class="button">Track My Order</button></a></td>
      <td><a href="#"><button class="button">Purchasing</button></a></td>
      <td><a href="#"><button class="button">Login </button></a></td>
      <td><a href="#"><button class="button">Sign Up </button></a></td>
  </tr>
</table>

  <table style="margin-top: -60px;">
  <tr>

      
      
      <td>
          
          <form>
              <div  style="text-align: center;">

                  <input class="search" type="text" name="name" id="name"/>
                  <input class="button1" type="submit" value="search" name="search"/>

              </div>
          </form>
      </td>
  </tr>
</table>
  </div>--> </td>
            </tr>
            <tr>
             <td id='hp'  class="dvi-1 hp-1"  style="width: 35%; ">             
            </td>
            <td style="width: 35%"> 
               <center> <table>
                 <tr  > <td>
                    <span class="fo">Laptop- 15.6” Full HD,</span>
                        </td>
                  <tr>
                    <td>
                        <span class="fo"> Intel i5-1035G1 CPU,</span>
                        </td>
                </tr>
                <tr>
                    <td>
                        <span class="fo"> 8GB RAM, 512GB SSD,</span>
                    </td>
                </tr>
                <tr>
                <td> 
                    <span class="fo">Backlit KeyBoard,</span>
                </td>
            </tr>
            <tr><td>
                <span class="fo"> Fingerprint,</span></td>
            </tr>
            <tr><td>
             <span class="fo">Windows 10 </span>
         </td>
            </tr>
        </tr>
    </table></center>
</td>

            <td >  
                <center>
                    <div>

                <button class="sb1 fo" >Add to cart</button>
            </div><br>

                <div>

                <button class="sb1 fo">buy now</button>
            </div>
            </center>


            </td>

        
        </table>
    </center>
        
    </body>
</html>
