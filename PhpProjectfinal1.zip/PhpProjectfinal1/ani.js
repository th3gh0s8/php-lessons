var x=2;

function b(){
    var y=document.getElementById("asus");
    y.className='dvi-1 asus-'+x;
    x++;
    if(x===5){
        x=1;
    }
}



var x=2;

function c(){
    var y=document.getElementById("hp");
    y.className='dvi-1 hp-'+x;
    x++;
    if(x===7){
        x=1;
    }
}

function d(){
    var y=document.getElementById("dell");
    y.className='dvi-1 dell-'+x;
    x++;
    if(x===6){
        x=1;
    }
}