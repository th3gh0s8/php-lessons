 /* 
 * Created on : May 14, 2020, 6:59:10 PM
 * Author     : chamuditha 
 */

function c(){
    var x=document.getElementById('x');
    x.className='r3d';
}

var x=2;

function n(){
    var y=document.getElementById("x");
    y.className='p'+x;
    x++;
    if(x===5){
        x=1;
    }
}


var x=2;

function d(){
    var y=document.getElementById("c");
    y.className='dvi-1 evn'+x;
    x++;
    if(x===7){
        x=1;
    }
}
var x=2;

function b(){
    var y=document.getElementById("bb");
    y.className='dvi-1 bb-'+x;
    x++;
    if(x===10){
        x=1;
    }
}
var x=2;

function bbing(){
    var y=document.getElementById("bbing");
    y.className='dvi-1 bbing-'+x;
    x++;
    if(x===7){
        x=1;
    }
}
var x=2;

function ar(){
    var y=document.getElementById("ar");
    y.className='dvi-1 ar-'+x;
    x++;
    if(x===6){
        x=1;
    }
}
var x=2;

function yo(){
    var y=document.getElementById("yo");
    y.className='dvi-1 yo-'+x;
    x++;
    if(x===6){
        x=1;
    }
}