<html>
    
    <?php
    include './DB_connection.php';
    ?>
    <head>
        
        <link type="text/css" rel="stylesheet" href="style.css"/>
    </head>
    <body class="b7">               <article>
  <header>
      <table style=" min-height: 200%; min-width: 200;  max-height: 100%; max-width: 100%;" >
          <tr class="navig-item" style="margin-left: 2%; width:50%;/*background-color: antiquewhite;*/">
              <td style="width:5%;"><a><img src="../icons/home(2).png" style=" min-height: 80%; min-width: 80%;  max-height: 90%; max-width: 90%;" /></a></td>
              <td style="width:5%;"><a><img src="../icons/previous.png" style="min-height: 100%; min-width: 100%; max-height: 80%; max-width: 80%;"/></a></td>
              <td> </td>
              <td> </td>
              <td> </td>
              <td> </td>
              <td  style="width:5%"><a><img src="../icons/menu(2).png" style="min-height: 100%; min-width: 100%; max-height: 25%; max-width: 25%; "/></a> </td>
          </tr>          
      </table>
  </header>
</article>
        <h1>Show orders here</h1>
        
        <table>
            <tr>
                <td>Invoice_item_id</td>
                <td>Quantity</td>
                <td>Product_id</td>
                <td>User_id</td>
                
                
            </tr>
             <tr>
                <td></td>
                <td></td>
                <td></td>
                <td>User_id</td>
                
                
            </tr>
            
            
            
        </table>
       
    </body>
</html>