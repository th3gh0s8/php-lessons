<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title></title>
        <link rel="stylesheet" type="text/css" href="stylesByGh8.css">
        <!--<link type="text/css" rel="stylesheet" href="style.css"/>-->
        

    </head>
    <body class="body">
        
       <article>
  <header>
      <table style=" min-height: 200%; min-width: 200;  max-height: 100%; max-width: 100%;" >
          <tr class="navig-item" style="margin-left: 2%; width:50%;/*background-color: antiquewhite;*/">
              <td style="width:5%;"><a><img src="../icons/home(2).png" style=" min-height: 200%; min-width: 200;  max-height: 90%; max-width: 90%;" /></a></td>
              <td style="width:5%;"><a><img src="../icons/previous.png" style="min-height: 100%; min-width: 100%; max-height: 80%; max-width: 80%;"/></a></td>
              <td> </td>
              <td> </td>
              <td> </td>
              <td> </td>
              <td  style="width:5%"><a><img src="../icons/menu(2).png" style="min-height: 100%; min-width: 100%; max-height: 25%; max-width: 25%; "/></a> </td>
          </tr>          
      </table>
  </header>
</article>
        
    <center>
        <div class="div0 f"> 
            <form action="checkLogin.php" method="POST" >
                <br> <input type="text" name="username" id="username" placeholder="username " class="tf" /><br><br>
                <br> <input type="password" name="password" id="passord" placeholder=" password" class="tf" /><br><br>
                <input class="btn1" type="submit" value="login"/>




            </form>
        </div>
    </center>
</body>
</html>
