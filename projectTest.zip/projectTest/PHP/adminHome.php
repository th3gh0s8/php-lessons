
<html>
    <head>
        <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <link rel="stylesheet" type="text/css" href="stylesByGh8.css">

        <!--<link type="text/css" rel="stylesheet" href="style.css"/>  -->  </head>
    <body class="b12">


        <article>
  <header>
      <table style=" min-height: 200%; min-width: 200;  max-height: 100%; max-width: 100%;" >
          <tr class="navig-item" style="margin-left: 2%; width:50%;/*background-color: antiquewhite;*/">
              <td style="width:5%;"><a><img src="../icons/home(2).png" style=" min-height: 80%; min-width: 80%;  max-height: 90%; max-width: 90%;" /></a></td>
              <td style="width:5%;"><a><img src="../icons/previous.png" style="min-height: 100%; min-width: 100%; max-height: 80%; max-width: 80%;"/></a></td>
              <td> </td>
              <td> </td>
              <td> </td>
              <td> </td>
              <td  style="width:5%"><a><img src="../icons/menu(2).png" style="min-height: 100%; min-width: 100%; max-height: 25%; max-width: 25%; "/></a> </td>
          </tr>          
      </table>
  </header>
</article>
        <div class="d1">

            <center style="margin-top: 9%;"><h1 class="h1">Welcome to admin panel</h1></center>


        </div>
        <center style="margin-left: 5%"><table>
            <tr>
                <td class="td1">
                    <a href="userManager.php" ><img src="../images/add-user.png"  width="70%" height="70%"  /></a>
                </td>
                <td class="td1">
                    <a href="productManager.php"><img src="../images/verify.png"  width="70%" height="70%"  /></a>
                </td>
                <td class="td1">
                    <a href="orderManager.php"><img src="../images/shopping-cart.png"  width="70%" height="70%"  /></a>
                </td>
            </tr>
            <tr class="tr1">
                <td >Register user</td>
                <td>Register products</td>
                <td>Register orders</td>

            </tr>
            </table></center><br><br><br><br><br><br><br>
        <a href="index.php" class="ab">back</a> -->

    </body>

</html>


<?php
?>

