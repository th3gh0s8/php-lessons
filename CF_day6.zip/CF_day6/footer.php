<footer style="background-color: activecaption" class="footer">
    Copywrite &copy; by CODEFEST 2021
</footer>